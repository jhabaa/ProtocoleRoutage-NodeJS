Tic-Tac-Toe
=================

Ceci est un projet personnel que j'ai réalisé dans le but de m'entraîner à l'utilisation du JavaScript.

Ce jeu est composé :
- d'un fichier en HTML 5 (validé par le W3C)
- d'un fichier en CSS 3 (validé par le W3C)
- d'un fichier en JavaScript

Il est possible d'y jouer ici :    
https://semrom.fr/jeux/tic-tac-toe/tic-tac-toe.html    
     
You can play here :    
https://semrom.fr/jeux/en/tic-tac-toe/tic-tac-toe.html

Romain Semler ©2014
